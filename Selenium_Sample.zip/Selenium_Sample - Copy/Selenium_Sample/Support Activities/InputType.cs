﻿namespace Selenium_Sample
{
    public enum inputType
    {
        ClassName,
        CssSelector,
        Id,
        LinkText,
        Name,
        TagName,
        XPath
    }

    public enum clickType
    {
        LeftClick,
        RightClick,
        DoubleClick
    }
}
