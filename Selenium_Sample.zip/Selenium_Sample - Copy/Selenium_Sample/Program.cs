﻿using System;
using OpenQA.Selenium;

namespace Selenium_Sample
{
    /// <summary>
    /// Selenium sample code to automate site Stack Overflow
    /// </summary>
    public class Selenium_StackOverFlow
    {
        /// <summary>
        /// Main function.. Starts automation from here
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            IWebDriver automationDriver = InitializeBrowser.initialize(); //Driver Initialization

            automationDriver = OpenBrowser.open(automationDriver, "https://stackoverflow.com/"); //Open Stack Overflow site

            IWebElement elemLogin = GetElement.get(automationDriver, inputType.XPath, "/html/body/header/div/ol/li[6]/a[1]");
            if (elemLogin != null) ClickElement.click(automationDriver, elemLogin, clickType.LeftClick);
            else
            {
                Console.WriteLine("{0}. Please check", "Element not found.");
                return;
            }

            IWebElement elemEmail = GetElement.get(automationDriver, inputType.XPath, "//*[@id='email']");
            if (elemEmail != null) SetText.set(elemEmail, "someone@something.com");
            else
            {
                Console.WriteLine("{0}. Please check", "Element not found.");
                return;
            }

            IWebElement elemPassword = GetElement.get(automationDriver, inputType.XPath, "//*[@id='password']");
            if (elemPassword != null) SetText.set(elemPassword, "myPassword");
            else
            {
                Console.WriteLine("{0}. Please check", "Element not found.");
                return;
            }

            IWebElement elemLoginStackExchange = GetElement.get(automationDriver, inputType.XPath, "//*[@id='submit-button']");
            if (elemLoginStackExchange != null) ClickElement.click(automationDriver, elemLoginStackExchange, clickType.LeftClick);
            else
            {
                Console.WriteLine("{0}. Please check", "Element not found.");
                return;
            }

            IWebElement elemGetAttrSample = GetElement.get(automationDriver, inputType.Id, "nav-questions");
            if (elemGetAttrSample != null)
            {
                string attributeStackOverFlow = GetAttribute.get(elemGetAttrSample, "href");
                Console.WriteLine("Scrapped Text : {0}.", attributeStackOverFlow);
            }
            else
            {
                Console.WriteLine("{0}. Please check", "Element not found.");                
            }
        }
    }
}
