﻿using OpenQA.Selenium;

namespace Selenium_Sample
{
    /// <summary>
    /// Finds DOM element based on inputs
    /// </summary>
    public static class GetElement
    {
        /// <summary>
        /// Return the DOM element absed on the inputs given
        /// </summary>
        /// <param name="driver">Current Web Driver</param>
        /// <param name="inpType">Type of Input</param>
        /// <param name="input">Input String</param>
        /// <returns></returns>
        public static IWebElement get(IWebDriver driver, inputType inpType, string input)
        {
            IWebDriver _driver = driver;

            By typeBy = By.XPath(input);

            switch (inpType)
            {
                case inputType.ClassName: typeBy = By.ClassName(input); break;
                case inputType.CssSelector: typeBy = By.CssSelector(input); break;
                case inputType.Id: typeBy = By.Id(input); break;
                case inputType.LinkText: typeBy = By.LinkText(input); break;
                case inputType.Name: typeBy = By.Name(input); break;
                case inputType.TagName: typeBy = By.TagName(input); break;
                case inputType.XPath: typeBy = By.XPath(input); break;
            }

            IWebElement elem = _driver.FindElement(typeBy);

            return elem;
        }
    }
}
