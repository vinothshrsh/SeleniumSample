﻿using OpenQA.Selenium;
using System;

namespace Selenium_Sample
{
    /// <summary>
    /// Finds the requested attribute of the DOM elem
    /// </summary>
    public static class GetAttribute
    {
        /// <summary>
        /// Gets the requested attribute of the DOM elem
        /// </summary>
        /// <param name="elem"></param>
        /// <param name="attrName"></param>
        /// <returns></returns>
        public static string get(IWebElement elem, string attrName)
        {
            IWebElement _elem = elem;

            return Convert.ToString(_elem?.GetAttribute(attrName));
        }
    }
}
