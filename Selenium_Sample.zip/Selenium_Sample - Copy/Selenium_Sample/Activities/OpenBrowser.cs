﻿using OpenQA.Selenium;

namespace Selenium_Sample
{
    /// <summary>
    /// Class to Open the requested URL with the Chrome Browser
    /// </summary>
    public static class OpenBrowser
    {
        /// <summary>
        /// Opens the Chrome Browser with the requested url
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="url"></param>
        /// <returns>Chrome driver instance</returns>
        public static IWebDriver open(IWebDriver driver, string url)
        {
            IWebDriver _driver = driver;

            _driver.Navigate().GoToUrl(url);
            _driver.Manage().Window.Maximize();

            return _driver;
        }
    }
}
