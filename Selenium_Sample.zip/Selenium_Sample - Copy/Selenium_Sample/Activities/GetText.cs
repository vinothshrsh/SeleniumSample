﻿using System;
using OpenQA.Selenium;

namespace Selenium_Sample
{
    /// <summary>
    /// Extract text from the DOM Element
    /// </summary>
    public static class GetText
    {
        /// <summary>
        /// Fetch the text from the DOM elem given
        /// </summary>
        /// <param name="elem"></param>
        /// <returns></returns>
        public static string get(IWebElement elem)
        {
            IWebElement _elem = elem;
            return Convert.ToString(_elem?.Text);
        }
    }
}
