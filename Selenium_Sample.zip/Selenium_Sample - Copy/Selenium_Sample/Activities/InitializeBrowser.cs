﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System.Diagnostics;
using System.Reflection;

namespace Selenium_Sample
{
    /// <summary>
    /// Class to Intialize Chrome Browser
    /// </summary>
    public static class InitializeBrowser
    {
        /// <summary>
        /// Method to initialize Chrome browser
        /// </summary>
        /// <returns>Chrome instance</returns>
        public static IWebDriver initialize()
        {

            //Initializing Chrome Options
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.Proxy = null;
            chromeOptions.AddArguments("--no-sandbox");
            chromeOptions.AddArguments("--disable-gpu");

            IWebDriver _driver = new ChromeDriver(chromeOptions);
            ForceExecutorToSupplyKeepAlive((ChromeDriver)_driver);

            return _driver;
        }

        /// <summary>
        /// Method to keep alive chrome browser
        /// </summary>
        /// <param name="driver">Chrome Driver Instance</param>
        private static void ForceExecutorToSupplyKeepAlive(ChromeDriver driver)
        {
            var commandExecutor = GetPropertyValue<ICommandExecutor>(driver, "CommandExecutor");
            var httpCommandExecutor = GetPropertyValue<HttpCommandExecutor>(commandExecutor, "HttpExecutor");
            httpCommandExecutor.SendingRemoteHttpRequest += (sender, args) =>
            {
                var sp = args.Request.ServicePoint;
                var prop = sp.GetType().GetProperty("HttpBehaviour", BindingFlags.Instance | BindingFlags.NonPublic);
                Debug.Assert(prop != null, nameof(prop) + " != null");
                prop.SetValue(sp, (byte)0, null);
            };
        }

        /// <summary>
        /// Support Actvity to fetch property
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        private static PropertyInfo GetProperty(object obj, string property)
        {
            return obj.GetType().GetProperty(property, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
        }

        /// <summary>
        /// Support Activity to fetch property of Type<T>
        /// </summary>
        /// <typeparam name="T">Generic Type</typeparam>
        /// <param name="obj"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        private static T GetPropertyValue<T>(object obj, string property)
        {
            return (T)GetProperty(obj, property)?.GetValue(obj);
        }
    }
}
