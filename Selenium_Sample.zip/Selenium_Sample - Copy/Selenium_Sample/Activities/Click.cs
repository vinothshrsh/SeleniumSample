﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace Selenium_Sample
{
    /// <summary>
    /// Performs click to the DOM element
    /// </summary>
    public static class ClickElement
    {
        /// <summary>
        /// Performs click to the given DOM element
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="elem"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static bool click(IWebDriver driver, IWebElement elem, clickType type)
        {
            IWebDriver _driver = driver;
            IWebElement _elem = elem;

            Actions action = new Actions(_driver);

            switch (type)
            {
                case clickType.LeftClick:
                    action.MoveToElement(_elem).Click().Build().Perform();
                    return true;
                    break;
                case clickType.RightClick:
                    action.MoveToElement(_elem).ContextClick().Build().Perform();
                    return true;
                    break;
                case clickType.DoubleClick:
                    action.MoveToElement(_elem).DoubleClick().Build().Perform();
                    return true;
                    break;
            }
            return false;
        }
    }
}
