﻿using OpenQA.Selenium;

namespace Selenium_Sample
{
    /// <summary>
    /// Write the given text to the DOM Element
    /// </summary>
    public static class SetText
    {
        /// <summary>
        /// Writes the given text to the DOM element
        /// </summary>
        /// <param name="elem"></param>
        /// <param name="text"></param>
        /// <returns></returns>
        public static bool set(IWebElement elem, string inputText)
        {
            IWebElement _elem = elem;

            if (_elem != null)
            {
                _elem.SendKeys(inputText);
                return true;
            }
            return false;
        }
    }
}
